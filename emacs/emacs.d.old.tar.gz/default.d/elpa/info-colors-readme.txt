This is a modern adaption of the extra coloring provided by Drew
Adams' `info+' package.

To enable this:

    (add-hook 'Info-selection-hook 'info-colors-fontify-node)
