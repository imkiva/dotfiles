To use the theme, put any of the following two lines in your Emacs
configuration file:

  (load-theme 'immaterial-dark t)    ;; dark variant
  (load-theme 'immaterial-light t)   ;; light variant

Requirements: Emacs 25.
