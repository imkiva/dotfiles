To use it, put the following in your Emacs configuration file:

  (load-theme 'material t)

Requirements: Emacs 24.
