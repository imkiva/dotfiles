Local playground for the Rust programs similar to play.rust-lang.org.
`M-x rust-playground` and type you rust code then make&run it with `C-c C-c`.
Toggle between Cargo.toml and main.rs with `C-c b`
Delete the current playground and close all buffers with `C-c k`

Playground requires preconfigured environment for Rust language.

It is port of github.com/grafov/go-playground for Go language.
