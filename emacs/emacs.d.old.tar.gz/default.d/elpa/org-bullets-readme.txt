Show org-mode bullets as UTF-8 characters.

This is a legacy package maintained with a focus on preservation.
It has an unofficial successor package (org-superstar).  This means
that new features will no longer be added, and backwards
compatibility will be preserved.

It's unofficial successor package is available on MELPA.  You can
also find it on GitHub:
https://github.com/integral-dw/org-superstar-mode
