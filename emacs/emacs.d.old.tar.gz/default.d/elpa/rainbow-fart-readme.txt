Usage:
(add-hook 'prog-mode-hook #'rainbow-fart-mode)
