ox-latex-subfigure.el permits to export subfigure to latex
