This library allows you to automatically insert rust `use` statements based
on the current symbol
